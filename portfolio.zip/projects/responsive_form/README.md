# Project3
 
 Mobile-first responsive form made using media queries and flexbox. 

 Could implement BootStrap to make CSS code less complex. 

 are you interested in hiring a Front End Web Developer? Email me at: r.j.kamman@gmail.com

- Site was tested in Chrome for Windows, and FireFox for Windows. 
- HTML validated via the W3C Markup Validation Service.
- CSS validated via the W3C CSS Validation Service.
- JS checked via JS Hint and JS console.
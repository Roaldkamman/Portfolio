# Portfolio_InteractiveGallery
my 5th project, interactive gallery using JavaScript. (type mountains for example)

This project used some JQuery and a lightbox plugin. 

Using JavaScript logic to make a photo gallery interactive and searchable by description in real time. 

are you interested in hiring a Front End Web Developer? Email me at: r.j.kamman@gmail.com

- Site was tested in Chrome for Windows, and FireFox for Windows. 
- HTML validated via the W3C Markup Validation Service.
- CSS validated via the W3C CSS Validation Service.
- JS checked via JS Hint and JS console.

